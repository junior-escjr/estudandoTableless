<title>Pro Tableless - Agência web | Desenvolvimento Web</title>
<meta name="description" content="Home | Pro Tableless - Desenvolvimento de sites nos padrões web, Trabalhando para você conquistar novos clientes" />
<meta name="keywords" content="Design Digital, Lojas virtuais, Desenvolvimento de sites, Estrategia de vendas, Consultoria web, Criação de sistems" />
<style type="text/css">
.spacer{display:none;}
body{background:url(<?php setHome();?>/tpl/images/home_body_bg.png) repeat-x;}
#header{width:900px; height:162px;}
</style>
<?php setHeader();?>

<div id="home_slide">
	<div class="bloco_um">
    	<ul>
        	<li>
                <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/facebook.jpg&h=236&w=510&zc=1&q=100"
                             alt="Trabalho Facebook" title="Portfólio -Facebook" width="510" height="236">
                             
                <div class="slide_info">
                	<div class="site">FACEBOOK</div>
                    <div class="date">Lançamento: 05/09/2011</div>
                    <a href="http://facebook.com" title="Facebook" target="_blank">Ver Site</a>
                </div><!--/slide_info-->
            </li>
            <li>
                <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/twitter.jpg&h=236&w=510&zc=1&q=100"
                             alt="Trabalho Twitter" title="Portfólio - Twitter" width="510" height="236">
                <div class="slide_info">
                	<div class="site">TWITTER</div>
                    <div class="date">Lançamento: 05/09/2011</div>
                    <a href="http://twitter.com" title="Twitter" target="_blank">Ver Site</a>
                </div><!--/slide_info-->
            </li>
            <li>
                <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/upinside.png&h=236&w=510&zc=1&q=100"
                             alt="Trabalho UpInside" title="Portfólio - UpInside" width="510" height="236">
                <div class="slide_info">
                	<div class="site">UPINSIDE</div>
                    <div class="date">Lançamento: 05/09/2011</div>
                    <a href="http://upinside.com.br" title="UpInside" target="_blank">Ver Site</a>
                </div><!--/slide_info-->
            </li>
        </ul>
      
        
    </div><!--/blodco_um-->
    <div class="bloco_dois">
    	<ul>
    	<li>
        	<a href="#">
            <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/facebook.jpg&h=73&w=340&zc=1&q=100"
                         alt="Trabalho Facebook" title="Portfólio -Facebook" border="0">
            </a>
        </li>
        <li>
        	<a href="#">
            <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/twitter.jpg&h=73&w=340&zc=1&q=100"
                             alt="Trabalho Twitter" title="Portfólio - Twitter" border="0">
            </a>             
        </li>
        <li>
        	<a href="#">
            <img src="<?php setHome();?>/js/timthumb.php?src=<?php setHome();?>/tpl/midias/upinside.png&h=73&w=340&zc=1&q=100"
                         alt="Trabalho UpInside" title="Portfólio - UpInside" border="0">
             </a>            
       </li>
       </ul>
    </div><!--/blodco_dois-->
</div><!--/home_slide-->

<div class="spacer" style="display:block;"></div><!--/spacer-->
<div id="conteudo">
    <div class="fone">
    	<p>PRO TABLELESS A 6 ANOS FOCANDO EM VOCÊ E SEUS CLIENTES</p>
        <div class="bloco_fone">
        <strong>Ligue para nós:</strong> +55 (54) 3381.2185
        </div>
    </div><!--/fone-->
    
    <ul class="lista_home">
    	<li>
        	<img src="<?php setHome();?>/tpl/images/li_design.png" alt="Design Digital" title="Design Digital" border="0" />
            <h3>DESIGN DIGITAL</h3>
            <p>CRIAMOS LAYOUTS PARA WEB SITES, PROJETOS DE DESIGN PARA CAMPANHAS DE PUBLICIDADE, LAYOUTS PARA CARTÕES DE  VISITAS,
             PRECISANDO DE UMA ARTE GRÁFICA?</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_seo.png" alt="Otimização de Sites" title="Otimização de Sites" border="0" />
            <h3>OTIMIZAÇÃO DE SITES SEO</h3>
            <p>APLICAÇÃO DE TÉCNICAS QUE AUMENTAM A VISITAÇÃO DO SEU SITE E A POSIÇÃO DE EXIBIÇÃO EM MECANISMOS DE PESQUISA DA WEB, 
            TAIS COMO GOOGLE, YAHOO, BING, ETC.</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_cms.png" alt="Temas para CMS's" title="Temas para CMS's" border="0" />
            <h3>CRIAÇÃO DE TEMAS PARA CMS's</h3>
            <p>VOCÊ UTILIZA UM CMS EM SEU SITE? NOS CRIAMOS O TEMA PARA VOCÊ, ASSIM VOCÊ TERÁ SEU BLOG OU PORTAL COM CMS E VISUAL
             EXCLUSIVO E PROFISSIONAL!</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_sites.png" alt="Desenvolvimento de web sites" title="Desenvolvimento de web sites" border="0" />
            <h3>DESENVOLVIMENTO DE WEBSITES</h3>
            <p>CRIAMOS SITES DINÂMICOS ONDE VOCÊ PODE GERENCIAR SEU CONTEÚDO ATRAVÉS DE UM PAINEL EXCLUSIVO E QUE DISPENSA CONHECIMENTO
             EM PROGRAMAÇÃO!</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_lojas.png" alt="Lojas virtuais, E-commerce" title="Lojas virtuais, E-commerce" border="0" />
            <h3>LOJAS VIRTUAIS, E-COMMERCE</h3>
            <p>QUE TAL VENDER ONLINE? CRIAMOS LOJAS VIRTUAIS COMPLETAS COM SISTEMAS DE CALCULO DE FRETE, VÁRIOS SISTEMAS DE PAGAMENTO!</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_consultoria.png" alt="Consultoria, propaganda online" title="Consultoria, propaganda online" border="0" />
            <h3>CONSULTORIA EM PUBLICIDADE ONLINE</h3>
            <p>NÃO SABE O QUE ESTÁ FALTANDO PARA SUA EMPRESA DECOLAR NA INTERNET? NÓS PRESTAMOS CONSULTORIA E ANÁLISE DE VENDAS ONLINE.</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_sistemas.png" alt="Desenvolvimento de Sistemas Web" title="Desenvolvimento de Sistemas Web" border="0" />
            <h3>DESENVOLVIMENTO DE SISTEMAS WEB</h3>
            <p>SUA EMPRESA TEM ALGUMA PARTICULARIDADE ESPECIAL EM PUBLICAÇÃO DE CONTEÚDO NA INTERNET? NOS CRIAMOS O SISTEMA PARA VOCÊ!</p>
        </li>
        
        <li>
        	<img src="<?php setHome();?>/tpl/images/li_ferramentas.png" alt="Ferramentas Exclusivas" title="Ferramentas Exclusivas" border="0" />
            <h3>FERRAMENTAS EXCLUSIVAS PARA VOCÊ</h3>
            <p>ENQUETES DINÂMICAS, SISTEMAS DE NEWSLETTER, INTEGRAÇÃO COM REDES SOCIAIS. O QUE VOCÊ PRECISA? NÓS COLOCAMOS NO PAINEL DO SEU SITE!</p>
        </li>
    </ul><!--/lista_homr-->
    
</div><!--/conteudo-->

























