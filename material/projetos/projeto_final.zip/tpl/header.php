</head>
<body>
<div id="site">

<div id="header">
    <div class="logo">
        <a href="<?php setHome();?>" title="Pro Tableless - Imprimia | Home">
            <img src="<?php setHome();?>/tpl/images/logo.png" border="0" alt="Logo" title="Pro Tableless, Imprima o Anúncio" width="480" height="109" />
        </a>
    </div><!--/logo-->
    <div class="info_print">Anúncio impresso do site www.campusup.com.br/curso/curso-pro-tableless</div>
		<?php setMenu();?>
</div><!--/header-->
<div class="spacer"></div><!--/spacer-->

<div id="content">