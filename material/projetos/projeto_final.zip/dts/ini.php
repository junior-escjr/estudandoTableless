<?php
//DEFINE BANCO DE DADOS
define(HOST,'localhost');
define(USER,'root');
define(PASS,'');
define(DBSA,'protableless');

//DEFINE SITE
define(BASE,'http://www.campusup.com.br/projetos/protableless');
define(SITENAME, 'Pro Tableless - Agência Web');

//DEFINE SERVDOR DE E-MAIL
define(MAILHOST,'mail.campusup.com.br');
define(MAILPORT,'587');
define(MAILUSER, 'suporte@campusup.com.br');
define(MAILPASS, '');
?>